package main;

import java.awt.Graphics;

public class Player {
	public int X = 0;
	public int Y = 0;
	public void drawPlayer(int width, int height, Graphics g){
		g.drawRect(X, Y, width, height);
	}

}
