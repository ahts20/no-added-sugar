package main;

public class Logic {
	
	public void runLogic(Player player){
		player.X += 10;
		player.Y += 10;
	}

}
