package main;

import java.awt.Color;
import java.awt.Graphics;

import javax.swing.JPanel;

public class GameGraphics extends JPanel{
	//public Player player;
	public Main main;
	public Logic logic;
	
	public void paintComponent(Graphics g){
		//player = main.player;
		logic = new Logic();
		Player player = main.sendPlayer();
		super.paintComponent(g);
		this.setBackground(Color.BLACK);
		//Player
		
		g.setColor(Color.WHITE);
		
		player.drawPlayer(20, 20, g);
		logic.runLogic(player);
		player.drawPlayer(20, 20, g);
	
		
	}

}
