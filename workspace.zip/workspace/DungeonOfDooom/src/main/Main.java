package main;

import java.awt.GraphicsDevice;
import java.awt.GraphicsEnvironment;

public class Main{
	
	public static GameWindow frame;
	public static GameGraphics graphics;
	public static Player player = new Player();
	
	public static GraphicsDevice gd = GraphicsEnvironment.getLocalGraphicsEnvironment().getDefaultScreenDevice();
	public static int width = gd.getDisplayMode().getWidth();
	public static int height = gd.getDisplayMode().getHeight();
	
	public static void main(String[] args){
		init();
	
		while(1 == 1){
			graphics = new GameGraphics();
			frame.add(graphics);
		}
		
	}
	
	public static void init(){
		frame = new GameWindow("Dungeon", width, height);
		//frame.setFullScreen();

		/*graphics = new GameGraphics();
		frame.add(graphics);*/
		
		frame.setVisible(true);
	}
	
	//Senders 
	public static Player sendPlayer(){
		return player;
	}
	
}
