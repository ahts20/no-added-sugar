package main;

public class Logic {
	private boolean running = true;
	
	public void runLogic(Player player){
			player.X += 10;
			player.Y += 10;	
	}
}
