package main;

import java.awt.Color;
import java.awt.Graphics;

import javax.swing.JPanel;

public class GameGraphics extends JPanel{
	//public Player player;
	public int x = 0;
	public int y = 0;
	
	public void paintComponent(Graphics g){
		super.paintComponent(g);
		this.setBackground(Color.BLACK);
		//Player
		g.setColor(Color.WHITE);
		g.fillRect(x, y, 50, 50);
	}

}
