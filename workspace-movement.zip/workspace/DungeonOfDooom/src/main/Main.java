package main;

import java.awt.EventQueue;
import java.awt.GraphicsDevice;
import java.awt.GraphicsEnvironment;

public class Main{
	
	public static GameWindow gw;
	public static void main(String[] args){
		   EventQueue.invokeLater(new Runnable() {
	            public void run() {
	              gw = new GameWindow();
	            }
	        });
	}
	
}
