package main;

import java.awt.GraphicsDevice;
import java.awt.GraphicsEnvironment;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.AbstractAction;
import javax.swing.JFrame;
import javax.swing.Timer;


public class GameWindow extends JFrame{
	
	public GameGraphics gg = new GameGraphics();
	public static GraphicsDevice gd = GraphicsEnvironment.getLocalGraphicsEnvironment().getDefaultScreenDevice();
	public static int width = gd.getDisplayMode().getWidth();
	public static int height = gd.getDisplayMode().getHeight();
	
	public GameWindow(){
		
		ActionListener listener = new AbstractAction(){
			public void actionPerformed(ActionEvent e) {
				if(gg.x >= width){
					gg.x = 0;
					gg.repaint();
				}else{
					gg.x += 10;
					gg.repaint();
				}
			}
		};
		
		Timer timer = new Timer(100, listener);
		timer.start();
		add(gg);
		
		setTitle("Dungeon");
		setSize(width, height);
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setLocationRelativeTo(null);
		setVisible(true);
	}
}
