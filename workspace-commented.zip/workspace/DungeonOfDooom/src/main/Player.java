package main;

import java.awt.Graphics;

public class Player {
	//Set player coordinates.
	public static float X = 0;
	public static float Y = 0;
	
	//Method which takes in the graphics environment and adds the pler as a rectangle.
	public void drawPlayer(int width, int height, Graphics g){
		g.drawRect((int)X, (int)Y, width, height);
	}
	
	//Move player.
	public void movePlayer(){
		X += 10;
		Y += 8;
	}
	
	//getters
	public float getX(){
		return X;
	}
	public float getY(){
		return Y;
	}
	//Setters
	public void setX(float x){
		X = x;
	}
	public void setY(float y){
		Y = y;
	}

}
