package main;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.AbstractAction;
import javax.swing.Timer;

public class Logic {
	//Collects the player as an object.
	public Player player = new Player();
	
	//The run logic methods runs the main program.
	public void runLogic(){
		//Create an action listener which acts as a tick/processor for each frame.
		ActionListener listener = new AbstractAction(){
			
			public void actionPerformed(ActionEvent e) {
				//Check to see is the player reaches the far right or bottom boundary of the screen.
				if(player.getX() >= Main.width || player.getY() >= Main.height){
					//If the player reaches a boundary put them back at the start position.
					player.setX(0);
					player.setY(0);
					//Refresh the screen.
					Main.gw.gg.repaint();
				}else{
					//If they do not reach a boundary increase their positions.
					player.movePlayer();
					//Refresh the screen.
					Main.gw.gg.repaint();
				}
			}
		};
		
		Timer timer = new Timer(100, listener);
		timer.start();
	}
}
