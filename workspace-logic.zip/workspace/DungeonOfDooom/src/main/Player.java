package main;

import java.awt.Graphics;

public class Player {
	public static float X = 0;
	public static float Y = 0;
	
	public void drawPlayer(int width, int height, Graphics g){
		g.drawRect((int)X, (int)Y, width, height);
	}
	

}
