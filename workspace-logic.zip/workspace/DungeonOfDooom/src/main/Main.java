package main;

import java.awt.EventQueue;
import java.awt.GraphicsDevice;
import java.awt.GraphicsEnvironment;

public class Main{
	
	public static GameWindow gw;
	public static Logic logic = new Logic();
	
	private static GraphicsDevice gd = GraphicsEnvironment.getLocalGraphicsEnvironment().getDefaultScreenDevice();
	public static int width = gd.getDisplayMode().getWidth();
	public static int height = gd.getDisplayMode().getHeight();
	
	public static void main(String[] args){
	   EventQueue.invokeLater(new Runnable() {
            public void run() {
                gw = new GameWindow("Dungeon", width, height);
                logic.runLogic();
            }
        });
	}
}
