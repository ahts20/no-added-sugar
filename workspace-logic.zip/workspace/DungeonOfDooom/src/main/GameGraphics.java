package main;

import java.awt.Color;
import java.awt.Graphics;

import javax.swing.JPanel;

public class GameGraphics extends JPanel{
	public Player player = new Player();;
	
	public void paintComponent(Graphics g){
		super.paintComponent(g);
		this.setBackground(Color.BLACK);
		//Player
		g.setColor(Color.WHITE);
		player.drawPlayer(20, 20, g);
	}

}
