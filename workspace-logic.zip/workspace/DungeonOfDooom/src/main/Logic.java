package main;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.AbstractAction;
import javax.swing.Timer;

public class Logic {
	
	public void runLogic(){
		
		ActionListener listener = new AbstractAction(){
			public void actionPerformed(ActionEvent e) {
				if(Player.X >= Main.width || Player.Y >= Main.height){
					Player.X = 0;
					Player.Y = 0;
					Main.gw.gg.repaint();
				}else{
					Player.X += 10;
					Player.Y += 5;
					Main.gw.gg.repaint();
				}
			}
		};
		
		Timer timer = new Timer(100, listener);
		timer.start();
	}
}
