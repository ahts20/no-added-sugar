package main;

import javax.swing.JFrame;

public class GameWindow extends JFrame{
	
	public GameGraphics gg = new GameGraphics();
	
	public GameWindow(String title, int width, int height){
		//Setting Graphics
		add(gg);
		//Setting Window
		setTitle(title);
		setSize(width, height);
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setLocationRelativeTo(null);
		setVisible(true);
	}
}
