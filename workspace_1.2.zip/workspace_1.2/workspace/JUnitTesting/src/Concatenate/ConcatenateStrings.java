package Concatenate;

public class ConcatenateStrings {
	
	public String concatenate(String one, String two){
		return one + two;
	}
	
	public int multiply(int number1, int number2){
		return number1 * number2;
	}
	
}
