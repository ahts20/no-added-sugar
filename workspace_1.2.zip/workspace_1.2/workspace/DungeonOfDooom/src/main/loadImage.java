package main;

import java.awt.image.BufferedImage;
import java.io.IOException;
import javax.imageio.ImageIO;

public class loadImage {
	//Collects image and returns printable to screen.
	private BufferedImage image;
	
	public BufferedImage LoadImageFrom(String path) throws IOException{
		image = ImageIO.read(getClass().getResource(path));
		
		return image;
	}
}
